import './projectList.css'
import MainHeader from './projectListComponents/mainHeader'
import MainSection from './projectListComponents/mainSection'

export default function ProjectList () {
    return(
        <div>
            <MainHeader />
            <MainSection />
        </div>
    )
}